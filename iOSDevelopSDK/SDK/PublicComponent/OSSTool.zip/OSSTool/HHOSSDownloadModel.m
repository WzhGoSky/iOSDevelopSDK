//
//  HHOSSDownloadModel.m
//  AFNetworking
//
//  Created by Hayder on 2018/12/18.
//

#import "HHOSSDownloadModel.h"

@implementation HHOSSDownloadModel

@end
